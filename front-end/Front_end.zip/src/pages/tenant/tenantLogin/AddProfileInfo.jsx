import { useEffect, useState } from "react";
import { FaEdit } from "react-icons/fa";
import { toast } from "react-toastify";
import { getUserProfile, updateProfile } from "../../../api/auth/auth";
import { useNavigate } from "react-router-dom";
import { FiTrash2 } from "react-icons/fi";
import { UseUser } from "../../../context/UserContext";

function AddProfileInfo() {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const {user,setUser}=UseUser()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    role: "tenant",
    profileImage: null,
    cnicImage: [],
    phone: "",
    address: {
      country: "",
      state: "",
      city: "",
      sector: "",
      street: "",
      houseNo: "",
    },
  });


  useEffect(() => {
    setFormData({
      ...formData,
      name: user.name,
      email: user.email,
    });
  }, []);

  const handleRoleChange = (e) => {
    setFormData({ ...formData, role: e.target.value });
  };

  const handleProfileImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({
        ...formData,
        profileImage: file,
      });
    }
  };

  const handleCnicImageUpload = (e) => {
    const file = e.target.files;
    if (file && formData.cnicImage.length < 2) {
      setFormData({
        ...formData,
        cnicImage: [...formData.cnicImage, ...file],
      });
    }
  };

  const handleDeleteImage = (index) => {
    setFormData((prevFormData) => ({
      ...prevFormData, // Spread the rest of the formData
      cnicImage: prevFormData.cnicImage.filter((_, i) => i !== index),
    }));
  };
  

  
  const handleAddressChange = (e, field) => {
    setFormData({
      ...formData,
      address: {
        ...formData.address,
        [field]: e.target.value,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);

      // Prepare FormData
      const data = new FormData();

      // Append simple fields
      data.append("name", formData.name);
      data.append("email", formData.email);
      data.append("role", formData.role);
      data.append("phone", formData.phone);

      // Append nested address fields
      Object.keys(formData.address).forEach((key) => {
        data.append(`address[${key}]`, formData.address[key]);
      });

      // Append profile image (if exists)
      if (formData.profileImage) {
        data.append("profileImage", formData.profileImage);
      }

      // Append CNIC images
      formData.cnicImage.forEach((file) => {
        data.append("cnicImage", file);
      });

      const response = await updateProfile(data);
      if (response.status === 200) {
        if (user.googleId === "") {
          navigate("/login");
          toast.success("profile completed");
          localStorage.clear();
        } else {
          const res = await getUserProfile();
          localStorage.setItem(
            "userData",
            JSON.stringify(res.data.data.user)
          );
          setUser(res.data.data.user);
          if (res.data.data.user.role==="tenant") {   
            navigate("/");
          }else if (res.data.data.user.role==="landowner") {
            navigate("/landowner/");
          } else if (res.data.data.user.role === "admin") {
            navigate("/admin/");
          }else if (res.data.data.user.role === "serviceman") {
            navigate("/serviceman/");
          }
        }
      } else if (response.status === 404) {
        toast.warn(response.response.data.message);
      }
      // eslint-disable-next-line no-unused-vars
    } catch (error) {
      toast.error("Something went wrong. Please try again later.");
      console.log(error);
      
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-28">
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-full max-w-lg p-8 bg-white rounded-lg shadow-md">
          <h2 className="mb-6 text-2xl font-semibold">
            Add your personal info
          </h2>

          <form className="space-y-4" onSubmit={handleSubmit}>
            {/* Profile Image Upload */}
            <div className="flex flex-col items-center mb-6">
              <div className="relative overflow-hidden border rounded-full w-52 h-52">
                {formData.profileImage ? (
                  <img
                    src={URL.createObjectURL(formData.profileImage)}
                    alt="Profile Preview"
                    className="object-cover w-full h-full"
                  />
                ) : (
                  <div className="flex items-center justify-center w-full h-full text-gray-400 bg-gray-100">
                    No Image
                  </div>
                )}
                <button className="absolute flex items-center justify-center p-2 text-white rounded-full bg-primaryColor bottom-7 right-7 hover:bg-primaryColor/80">
                  <FaEdit size={16} />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleProfileImageUpload}
                    className="absolute top-0 left-0 w-full h-full opacity-0 cursor-pointer"
                  />
                </button>
              </div>
            </div>

            {/* CNIC Image Upload */}
            <div className="flex flex-col mb-6">
              <label className="mb-2 text-gray-700">CNIC Image</label>
              <div className="flex items-center w-full gap-2 mb-2 overflow-hidden border rounded-lg">
                {formData.cnicImage.length > 0 ? (
                  formData.cnicImage.map((image, index) => (
                    <div key={index} className="relative w-full h-32">
                      <img
                        src={URL.createObjectURL(image)}
                        alt={`CNIC Preview ${index + 1}`}
                        className="object-cover w-full h-full"
                      />
                      <button
                        onClick={() => handleDeleteImage(index)}
                        className="absolute p-2 text-white bg-red-500 rounded-full top-2 right-2"
                      >
                        <FiTrash2 size={20} />
                      </button>
                    </div>
                  ))
                ) : (
                  <div className="flex items-center justify-center w-full h-32 text-gray-400 bg-gray-100">
                    No Image
                  </div>
                )}
              </div>

              <button className="relative flex items-center justify-center p-2 text-white bg-primaryColor hover:bg-primaryColor/80">
                <FaEdit size={16} /> Add
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handleCnicImageUpload}
                  className="absolute top-0 left-0 w-full h-full opacity-0 cursor-pointer"
                />
              </button>
            </div>

            {/* Full Name */}
            <div>
              <label className="block text-gray-700">name</label>
              <input
                type="text"
                placeholder="John Doe"
                value={formData.name}
                className="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-600"
              />
            </div>

            {/* Email Address */}
            <div>
              <label className="block text-gray-700">Email address</label>
              <input
                type="email"
                placeholder="johndoe@gmail.com"
                value={formData.email}
                className="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-600"
              />
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-gray-700">Phone number</label>
              <input
                type="text"
                placeholder="(123) 456-7890"
                className="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-600"
              />
            </div>

            {/* Home Address */}
            <div className="space-y-4">
              <label className="block text-gray-700">Address</label>
              <div className="relative flex flex-wrap items-center gap-4 mb-6">
                <input
                  type="text"
                  placeholder="Country name"
                  value={formData.address.country}
                  onChange={(e) => handleAddressChange(e, "country")}
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="State name"
                  value={formData.address.state}
                  onChange={(e) => handleAddressChange(e, "state")}
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="City name"
                  value={formData.address.city}
                  onChange={(e) => handleAddressChange(e, "city")}
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="Street Number"
                  value={formData.address.street}
                  onChange={(e) => handleAddressChange(e, "street")}
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="Sector Number"
                  value={formData.address.sector}
                  onChange={(e) => handleAddressChange(e, "sector")}
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />

                <input
                  type="text"
                  placeholder="House Number"
                  value={formData.address.houseNo}
                  onChange={(e) => handleAddressChange(e, "houseNo")}
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />
              </div>
            </div>

            {/* Role Dropdown */}
            <div className="flex flex-col items-start w-full">
              <label className="block text-gray-700">Role</label>
              <select
                value={formData.role}
                onChange={handleRoleChange}
                className="w-full p-3 text-gray-800 border border-gray-300 rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-600"
              >
                <option value="tenant">Tenant</option>
                <option value="landowner">LandOwer</option>
                <option value="serviceman">Serviceman</option>
              </select>
            </div>

            {/* Save Button */}
            <div className="flex justify-end mt-6">
              <button
                disabled={loading}
                type="submit"
                className="px-6 py-2 text-white rounded-lg bg-primaryColor hover:bg-primaryColor/80"
              >
                {loading ? "loading..." : "Save"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default AddProfileInfo;
