import { useEffect, useState } from "react";
import { FaEdit } from "react-icons/fa";
import { UseUser } from "../../../context/UserContext";
import { updateProfile } from "../../../api/auth/auth";
import { toast } from "react-toastify";

function Profile() {
  const { user ,setUser} = UseUser();
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [role, setRole] = useState(""); // State to store the selected role
  const [profileImage, setProfileImage] = useState(null); // Profile image state
  const [addressForm, setAddressForm] = useState({
    country: "",
    state: "",
    city: "",
    sector: "",
    street: "",
    houseNo: "",
  });

  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (user) {
      setEmail(user.email);
      setFullName(user.name);
      setPhoneNumber(user.phone);
      setProfileImage(user.image);
      setRole(user.role);
      setAddressForm(user.address);
    }
  }, [user]);
  const handleRoleChange = (e) => {
    setRole(e.target.value);
  };

  const handleProfileImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfileImage(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);

      // Prepare FormData
      const data = new FormData();

      // Append simple fields
      data.append("name", fullName);
      data.append("email", email);
      data.append("role", role);
      data.append("phone", phoneNumber);

      // Append nested address fields
      Object.keys(addressForm).forEach((key) => {
        data.append(`address[${key}]`, addressForm[key]);
      });

      // Append profile image (if exists)
      if (profileImage) {
        data.append("profileImage", profileImage);
      }


      const response = await updateProfile(data);

      if (response.status === 200) {
        toast.success("profile Updated");
        const userData = JSON.stringify(response.data.data.updatedUser);
        localStorage.setItem("userData", userData);
        setUser(response.data.data.updatedUser)
      } else if (response.status === 404) {
        toast.warn(response.response.data.message);
      }
      // eslint-disable-next-line no-unused-vars
    } catch (error) {
      toast.error("Something went wrong. Please try again later.");
      
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-28">
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-full max-w-lg p-8 bg-white rounded-lg shadow-md">
          <h2 className="mb-6 text-2xl font-semibold">
            Edit your personal info
          </h2>

          <form className="space-y-4" onSubmit={handleSubmit}>
            {/* Profile Image Upload */}
            <div className="flex flex-col items-center mb-6">
              <div className="relative overflow-hidden border rounded-full w-52 h-52">
                {profileImage ? (
                  <img
                    src={profileImage}
                    alt="Profile Preview"
                    className="object-cover w-full h-full"
                  />
                ) : (
                  <div className="flex items-center justify-center w-full h-full text-gray-400 bg-gray-100">
                    No Image
                  </div>
                )}
                <button className="absolute flex items-center justify-center p-2 text-white rounded-full bg-primaryColor bottom-7 right-7 hover:bg-primaryColor/80">
                  <FaEdit size={16} />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleProfileImageUpload}
                    className="absolute top-0 left-0 w-full h-full opacity-0 cursor-pointer"
                  />
                </button>
              </div>
            </div>

            {/* Full Name */}
            <div>
              <label className="block text-gray-700">Full name</label>
              <input
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                type="text"
                placeholder="John Doe"
                className="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-600"
              />
            </div>

            {/* Email Address */}
            <div>
              <label className="block text-gray-700">Email address</label>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                placeholder="johndoe@gmail.com"
                className="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-600"
              />
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-gray-700">Phone number</label>
              <input
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                type="text"
                placeholder="+9232 456-7890"
                className="w-full px-4 py-2 mt-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-gray-600"
              />
            </div>

            {/* Home Address */}
            <div className="space-y-4">
              <label className="block text-gray-700">Address</label>
              <div className="relative flex flex-wrap items-center gap-4 mb-6">
                <input
                  type="text"
                  placeholder="Country name"
                  value={addressForm.country}
                  onChange={(e) =>
                    setAddressForm({ ...addressForm, country: e.target.value })
                  }
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="State name"
                  value={addressForm.state}
                  onChange={(e) =>
                    setAddressForm({ ...addressForm, state: e.target.value })
                  }
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="City name"
                  value={addressForm.city}
                  onChange={(e) =>
                    setAddressForm({ ...addressForm, city: e.target.value })
                  }
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="Street Number"
                  value={addressForm.street}
                  onChange={(e) =>
                    setAddressForm({ ...addressForm, street: e.target.value })
                  }
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="Sector Number"
                  value={addressForm.sector}
                  onChange={(e) =>
                    setAddressForm({ ...addressForm, sector: e.target.value })
                  }
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />

                <input
                  type="text"
                  placeholder="House Number"
                  value={addressForm.houseNo}
                  onChange={(e) =>
                    setAddressForm({ ...addressForm, houseNo: e.target.value })
                  }
                  className="p-4 mt-1 bg-gray-100 border rounded-lg focus:outline-none"
                />
              </div>
            </div>

            {/* Role Dropdown */}
            <div className="flex flex-col items-start w-full">
              <label className="block text-gray-700">Role</label>
              <select
                value={role}
                onChange={handleRoleChange}
                className="w-full p-3 text-gray-800 border border-gray-300 rounded-lg bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-600"
              >
                <option value="tenant">Tenant</option>
                <option value="landowner">Landowner</option>
                <option value="serviceman">Serviceman</option>
              </select>
            </div>

            {/* Save Button */}
            <div className="flex justify-end mt-6">
              <button
                disabled={loading}
                type="submit"
                className="px-6 py-2 text-white rounded-lg bg-primaryColor hover:bg-primaryColor/80"
              >
                {loading ? "loading..." : "Save"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Profile;
